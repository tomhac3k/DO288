To do this exercise you must change to another directory.
Please, run the following command:

```bash
cd  ~/DO288/DO288-apps/apps/builds-applications/vertx-site
```
