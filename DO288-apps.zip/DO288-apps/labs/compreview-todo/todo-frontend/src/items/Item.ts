export interface Item {
  id?: number;
  description: string; // max length: 100, min length: 5
  done: boolean;
}
